import {ProductContext} from '@oracle-cx-commerce/react-ui/contexts';
import {useContext} from 'react';

export const getProductName = state => state || {};

// export const getComponentsData = () => {
//     const Productctx = useContext(ProductContext);
//     return Productctx;
// }