export const _getProduct = {

    // This action uses a Saga to invoke the _getProduct endpoint.
    endpoints: ['_getProduct']
 };