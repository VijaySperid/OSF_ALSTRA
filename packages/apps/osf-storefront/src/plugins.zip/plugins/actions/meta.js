/*
 ** Copyright (c) 2020 Oracle and/or its affiliates.
 */

export * from '@oracle-cx-commerce/actions/meta';
export {_getProduct} from './product/meta';