export default {
    packageId: '@oracle-cx-commerce/subscribers',
    description: 'Add your description',
    endpoints: ['getProduct' || ''],
    triggers: 'getProduct',
    author: 'yourUserName'
  };