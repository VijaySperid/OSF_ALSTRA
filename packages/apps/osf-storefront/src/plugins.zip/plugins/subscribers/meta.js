/*
 ** Copyright (c) 2020 Oracle and/or its affiliates.
 */

export * from '@oracle-cx-commerce/subscribers/meta';
export const productSubcriber = () => import('./product/meta');