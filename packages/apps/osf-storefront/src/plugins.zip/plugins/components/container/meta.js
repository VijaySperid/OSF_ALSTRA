import config from './config/index';

export const Container = {
  type: 'container',
  config: {
    ...config
  }
};