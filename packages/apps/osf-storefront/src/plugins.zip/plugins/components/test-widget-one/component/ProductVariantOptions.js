/*
 ** Copyright (c) 2020 Oracle and/or its affiliates.
 */
/* eslint-disable jsx-a11y/no-onchange */

import {ContainerContext, ProductContext, StoreContext} from '@oracle-cx-commerce/react-ui/contexts';
import React, {useContext, useState, useCallback, useEffect } from 'react';
import VariantSelect from '@oracle-cx-commerce/react-widgets/product/product-variant-options/components/product-variant-select';
import Styled from '@oracle-cx-commerce/react-components/styled';
import css from '@oracle-cx-commerce/react-widgets/product/product-variant-options/styles.css';
import {getCurrentPageId} from '@oracle-cx-commerce/commerce-utils/selector';

/**
 * Utility method to get the currently selected variant
 * @param {Object} pVariantOptions the variant options
 * @return {String} the selected option
 */
const getCurrentSelectedItem = (pVariantOptions = []) => {
  return Object.keys(pVariantOptions).reduce((previous, current) => {
    const {selectedValue} = pVariantOptions[current];

    return `${previous}${current}=${selectedValue !== null ? selectedValue : '.+'};`;
  }, '');
};

/**
 * A widget for displaying product variant options in the form of drop down, buttons or swatches based on configuration.
 * The temporary selections of the variant options and sku are maintained at the ContainerContext level.
 * This information is used by other widgets to get selected Sku, selected Sku images, selected Sku stock status.
 * Only valid Sku options can be selected, invalid options or unavailable options are disabled.
 */
const ProductVariantOptions = ({productDesc}) => {

  const [ selections, setSelections] = useState({});
  // resources
  const swatchVariantOption = 'color';

  // context
  // const {getState} = useContext(StoreContext);

  // const pageId = '';

  const {
    id: productId,
    variantOptionPermutations,
    variantOptionsSeed,
    variantToSkuLookup
  } = productDesc;
  // state
  const [optionChanged, setOptionChanged] = useState(false);
  const variantOptions = {...variantOptionsSeed};

  useEffect(() => {
    const color_option =  variantOptions['sku-AirConditioner_x_color'].options;
    variantOptions['sku-AirConditioner_x_color'].selectedValue = color_option[0].value;

    // default value to power
    const power_option = variantOptions['sku-AirConditioner_x_power'].options;
    variantOptions['sku-AirConditioner_x_power'].selectedValue = power_option[0].value;

    // default value to soldBy
    const option = variantOptions['sku-AirConditioner_x_soldBy'].options;
    const indexVal = option.find((x) => x.name === 'Carrier');
    variantOptions['sku-AirConditioner_x_soldBy'].selectedValue = indexVal.value;

    const currentSelectedItem = getCurrentSelectedItem(variantOptions);
    const xskuId = variantToSkuLookup[currentSelectedItem];
    localStorage.setItem('currentSku', xskuId);
  }, [])

  /**
   * Update and return the variant options with selections from URL, if any
   */
  const updateSelections = useCallback(() => {
    // get the latest selected item from the options
    const currentSelectedItem = getCurrentSelectedItem(variantOptions);
    const variantOptionsLite = {};
    // loop through each variant and enable/disable options
    Object.entries(variantOptions || {}).forEach(([optionKey, {selectedValue, optionId, optionName, options = {}}]) => {
      variantOptionsLite[optionKey] = {
        optionName,
        optionId,
        selectedValue
      };
      // loop through each variant option
      options.forEach(option => {
        const optionKeyValuePair = `${optionKey}=${option.value};`;
        // replace any matching value between = and ; with the option key, handles number or '.+' placeholder
        const newSelectedItemKey = currentSelectedItem.replace(new RegExp(`${optionKey}=.+?;`), optionKeyValuePair);
        const newSelectedItemKeyRegEx = new RegExp(newSelectedItemKey);
        // if the selected variant combination is not in the variantOptionPermutations then disable that variant
        option.disabled = !newSelectedItemKeyRegEx.test(new RegExp(variantOptionPermutations));
      });
    });
    setSelections({
      ...selections,
      variantOptions: variantOptionsLite,
      skuId: variantToSkuLookup[currentSelectedItem],
      selectedStore: {},
      isPickupInStoreOptionSelected: false
    });
  }, [selections, setSelections, variantOptionPermutations, variantOptions, variantToSkuLookup]);

  /**
   * Update and return the variant options with selections from URL, if any
   */
  (() => {
    // for the first time loading the page
    if (!optionChanged && variantOptions) {
      // const queryPart = pageId.split('?')[1];
      const urlParams = new URLSearchParams( {});
      const optionNameURL = urlParams.get('variantName');
      const optionValUrl = urlParams.get('variantValue');
      Object.entries(variantOptions).forEach(([, variantOption]) => {
        const {optionName, options = []} = variantOption;
        variantOption.selectedValue = null;
        if (optionNameURL && optionValUrl && optionName === optionNameURL) {
          const optionFound = options.find(({name}) => name === optionValUrl);
          if (optionFound) {
            variantOption.selectedValue = optionFound.value;
            setOptionChanged(true);
            updateSelections();
          }
        }
      });
    }
  })();

  /**
   * Handle the variant change for drop down, button & swatches
   * @param {String} value The value of the selected option
   * @param {String} optionKey The name of the selected option
   */
  const handleVariantOptionChange = useCallback(
    (value, optionKey) => {
      value = parseInt(value, 10);

      if (isNaN(value) || variantOptions[optionKey].selectedValue === value) {
        value = null;
      }
      // if(optionKey !== 'sku-AirConditioner_x_soldBy' ) {
      //   const option = variantOptions['sku-AirConditioner_x_soldBy'].options;
      //   console.log('option', option);
        
      //   const indexVal = option.find((x, index) => x.name === 'Carrier');
      //   console.log('indexVal', indexVal);
      //   variantOptions['sku-AirConditioner_x_soldBy'].selectedValue = indexVal.value;
      // }
      variantOptions[optionKey].selectedValue = value;
      !optionChanged && setOptionChanged(true);
      updateSelections();
    },
    [optionChanged, updateSelections, variantOptions]
  );

  /**
   * Decides the type of variant picker to use
   *
   * @param {Object} props the function payload
   * @param {number} props.optionKey the variant id
   * @param {Array} props.options the available options for variant
   * @param {String} props.selectedValue selected option value
   */
  const renderVariantSelectorType = (optionKey, options, selectedValue) => {

    return (
    <VariantSelect
        options={options}
        optionKey={optionKey}
        selectedValue={selectedValue}
        handleVariantOptionChange={handleVariantOptionChange}
    />
    );
    
  };
  console.log('STate', selections)
  return (
    <Styled id="ProductVariantOptions" css={css}>
      <div className="ProductVariantOptions">
        {Object.entries(variantOptions || {}).map(
          ([optionKey, {options = [], selectedValue, optionId, optionName}], index) => {
            if( index == 2) {
              return
            }
            let optionNameDisplay = optionName;
            if (optionId.endsWith(swatchVariantOption) && selectedValue !== null) {
              const {name} = options.find(option => option.value === selectedValue);
              optionNameDisplay += `: ${name}`;
            }

            return (
              <div key={`${optionId}-${optionKey}`} className="ProductVariantOptions__Wrapper">
                <span className="ProductVariantOptions__OptionName">{optionNameDisplay}</span>
                {renderVariantSelectorType(optionKey, options, selectedValue)}
              </div>
            );
          }
        )}
      </div>
    </Styled>
  );
};

export default ProductVariantOptions;
