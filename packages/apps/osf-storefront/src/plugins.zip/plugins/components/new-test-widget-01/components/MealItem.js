import React from "react";

const MealItem = (props) => {
  return (
    // <li className='meal'>
    //     <h3 className='MealItemName'>{props.name}</h3>
    //     <div className='MealItemDescription'>{props.description}</div>
    //     <div className='MealItemPrice'>{props.price}</div>

    // </li>

    //product  listing card container--GRID
  
      <div className="card">
        <div className="card-content">
          <div className="card-content__header"></div>
          <div className="card-content__body">
            <span className="subtitle">Non-Inverter</span>
            <div className="title">iCool Green Remote Top Discharge</div>
            <div className="rate">
              <div className="rate-stars">
                <div
                  className="Rating"
                  aria-label="Rating of this item is 3 out of 5"
                ></div>
              </div>
              <div className="rate-counts">(16)</div>
            </div>
            <span className="price">₱35,000.00</span>
          </div>
          <div className="card-content__footer">
            <button className="o-button-full">Compare</button>
          </div>
        </div>
      </div>
   
  );
};

export default MealItem;
