import React from "react";
import Styled from "@oracle-cx-commerce/react-components/styled";
import { connect } from "@oracle-cx-commerce/react-components/provider";
// import {getProductName,useComponentData} from '../../selectors';
import { getProductName } from "../../selectors";
import MealItem from "./components/MealItem";
// import {ProductContext} from '@oracle-cx-commerce/react-ui/contexts';

/*
 * Uncomment the following line to get the parameter substitution
 * function, e.g. t(someParameterizedResourceString, "someValue").
 */
import { t } from "@oracle-cx-commerce/utils/generic";

import css from "./styles.css";

let productList;
const NewTestWidget01 = (props) => {
  // const Productctx = useContext(ProductContext);
  productList = Object.values(props.searchRepository.pages)[0].results.records;
  // selectors
  const prodCTX = getProductName();
  console.log("props in collection page", props);
  console.log(
    "List of all products  in collection page new test widget one",
    productList
  );

  productList.map((item) => {
    console.log(
      "item.attributes[product.displayName]",
      item.attributes["product.displayName"][0]
    );
  });

  const mealList = productList.map((item, index) => {
    return (
      <MealItem
        id={index}
        key={index}
        name={item.attributes["product.displayName"][0]}
        price={item.attributes["sku.maxActivePrice"][0]}
        description={item.attributes["product.primaryImageAltText"][0]}
      ></MealItem>
    );
  });

  return (
    <Styled id="NewTestWidget01" css={css}>
      <div className="NewTestWidget01"> no0000000</div>
      {/* <ul>
        {mealList}
      </ul> */}
        <div className="cards">{mealList}</div>
    </Styled>
  );
};

export default connect(getProductName)(NewTestWidget01);
