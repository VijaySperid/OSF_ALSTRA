export const helloText = 'sample component text';
export const labelExtraInfo = '...with some extra info!';
export const labelSampleTranslation = 'A Translated Label';
