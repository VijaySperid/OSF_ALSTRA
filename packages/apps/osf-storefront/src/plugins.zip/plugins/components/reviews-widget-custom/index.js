import React, {useContext} from 'react';
import Styled from '@oracle-cx-commerce/react-components/styled';

/*
 * Uncomment the following line to get the parameter substitution
 * function, e.g. t(someParameterizedResourceString, "someValue").
 */
import {t} from '@oracle-cx-commerce/utils/generic';

import css from './styles.css';
import Reviews from './components/Revews';
import {connect} from '@oracle-cx-commerce/react-components/provider';
import { getProductName } from "../../selectors";

const ReviewsWidgetCustom = props => {
 
  return (
    <Styled id="ReviewsWidgetCustom" css={css}>
    <Reviews/>
    </Styled>
  );
};

export default connect(getProductName)(ReviewsWidgetCustom);
